console.log("Hy from Node Runtime ENV.");
console.warn("warning");
console.debug("Debug");
console.error("Error");
console.info("Information");


